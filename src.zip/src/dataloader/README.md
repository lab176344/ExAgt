**List of available dataloaders**
|   idx | name                    |   size | description                                                                                       |   samples | representation   |
|------:|:------------------------|-------:|:--------------------------------------------------------------------------------------------------|----------:|:-----------------|
|     0 | Barlow Twins Dataloader |      0 | Dataloader which gives two augumented version of the scenario with the target labels if available |         0 | [1, 0, 0, 0]     |
