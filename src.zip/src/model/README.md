**List of available models**
|   idx | name     |   size |   n_params |   input |   output |   task | description                                          |
|------:|:---------|-------:|-----------:|--------:|---------:|-------:|:-----------------------------------------------------|
|     0 | ResNet3D |    nan |        nan |     nan |      nan |    nan | 3D version of the ResNet                             |
|     1 | ResNet   |    nan |        nan |     nan |      nan |    nan | ResNet with possibility to generate different depths |
|     2 | ResNet   |    nan |        nan |     nan |      nan |    nan | ResNet with possibility to generate different depths |
